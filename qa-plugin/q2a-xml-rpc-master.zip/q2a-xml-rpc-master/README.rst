=================================
Question2Answer XML-RPC Server
=================================
-----------
Description
-----------
This is a plugin for **Question2Answer** that allows access via XML-RPC.

--------
Features
--------
- view questions stream
- view individual questions
- vote on questions and answers
- post questions, answers, and comments

------------
Installation
------------
#. Install Question2Answer_
#. Get the source code for this plugin from github_, either using git_, or downloading directly:

   - To download using git, install git and then type 
     ``git clone git://github.com/NoahY/q2a-xml-rpc.git xml-rpc``
     at the command prompt (on Linux, Windows is a bit different)
   - To download directly, go to the `project page`_ and click **Download**

#. navigate to your site, go to **Admin -> Plugins** on your q2a install and find the XML-RPC section.

.. _Question2Answer: http://www.question2answer.org/install.php
.. _git: http://git-scm.com/
.. _github:
.. _project page: https://github.com/NoahY/q2a-xml-rpc

----------
Disclaimer
----------
This is **alpha** code.  It may not work as expected.  It may corrupt your data.  Refunds will not be given.  If it breaks, you get to keep both parts.

-------
Release
-------
All code herein is Copylefted_.

.. _Copylefted: http://en.wikipedia.org/wiki/Copyleft

---------
About q2A
---------
Question2Answer is a free and open source platform for Q&A sites. For more information, visit:

http://www.question2answer.org/


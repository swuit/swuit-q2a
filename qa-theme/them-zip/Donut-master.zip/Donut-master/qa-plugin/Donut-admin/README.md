#Donut theme Admin panel#

Place this folder under qa-plugin directory of your q2a installation path 

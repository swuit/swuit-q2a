# Q2A-Infinity Theme

## Important
This theme is in **development stage**. it's release is only to let developers and enthusiasts use and help it's development via suggestions or requesting changes to code.

Do not use this theme untile it's beta or final version is released.

# Q2A Bootstrap

Bootstrap 3 for [Question2Answer](http://www.question2answer.org)

**This project is currently under development**

**For Q2A v1.5.3: [Q2A-Bootstrap v1.1.0](https://github.com/harshjv/q2a-bootstrap/tree/v1.1.0)**


## Installation

```sh
cd your-qa-project/qa-theme
git clone https://github.com/harshjv/q2a-bootstrap
```


## Author

[Harsh Vakharia](http://twitter.com/harshjv)


## License

GPL v2